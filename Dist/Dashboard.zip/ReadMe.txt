This is a pretty early release. So, docs here are minimal. :)

The dashboard has a number of features:
-OBD2 compatibility 
-Displays speed, tach, and trouble codes in real time
-Interfaces with WinAmp for music
-Displays album thumbnails for WinAmp music
-Touch-screen compatible interface
-Metric or imperial display
-Can display text messages from any program that can create a text log

Since I wrote it specifically for my 1996 Dodge Neon, it also has a number of limitations:
-Runs at 800x600 only
-Heavy CPU usage
-Most settings are hard coded
-Tach and Speedometer are always drawn as full-page left-to-right images
-Only supports US ISO through the BR16F84 interface IC. I got my box from http://obddiagnostics.com/, 
 and it is the only one I've tested.
-Limited error recovery.
-Always starts with KM/H, and WinAmp in shuffle mode
-External webcam image must be 'webcam.bmp' in the working folder and must be 160x120 pixels
-Only tested on Windows XP - might work on 2000. Not likely to work on any other.
-Font sizes, layouts, and colors are hard coded
-Bitmap filenames are hard coded, but may be changed. The masks must be mono bitmaps, with
 white representing all colored areas in the related color file (see the provided samples)

The frame rate is more or less limited by the OBD2 protocol itself.
Sometimes the box listed above can not communicate with the car - and must be reset by unplugging 
it from the car, and plugging it back in.

It's also intended to work with WinAmp, and most of the touchscreen interface is based on that.
If you don't have a touchscreen, you can use a mouse, but since it's hidden, you need to remember
where the cursor is. There are five regions on the screen for control:

	// Top Left - WinAmp Previous
	// Top Right - WinAmp Next
	// Top Center - Play/Pause
	// Bottom Left - Winamp Shuffle toggle
	// Bottom Right - Miles/KM/Mega Furlongs per Fortnight
	
While Winamp is playing, the Dashboard will look for a 120x120 BMP file with the same filename as the current song. If it can't find that, it will look in the same folder for a FOLDER.BMP. If either exist, it is displayed.

That's all there is to it right now - until I add some configuration, it'll probably only work
on US cars with the above interface chip. I ran it on a long (4000km round trip!) drive, and it
worked pretty damn well, except the laptop kept shutting off the LCD. But since the plan is to
install a VGA touchscreen instead, that's a minor detail.

Has now been tested on my 1996 Neon and 2005 RAV4.

To use: 
-Extract the zip file to a working folder, preferably C:\DASHBOARD.
-Install the fonts into the C:\Windows folder
-Edit Dashboard.ini for your system (there are very few configurable options, don't mess with the
 timeouts unless you need to)
-C:\Log.txt will be written if any errors occur, this usually gives more information as to the problem
-Connect the PC to your interface box, and the interface to the car
-Start Dashboard.exe

If it works, let me know! If it doesn't, well, it's too early to let me know. :)

NOTICE: To the best of my knowledge, I believe the fonts are redistributable (that's how *I* got them!)


//
// (C) 2005-2006 Mike Brent aka Tursi aka HarmlessLion.com
// This software is provided AS-IS. No warranty
// express or implied is provided.
//
// This notice defines the entire license for this software.
// All rights not explicity granted here are reserved by the
// author.
//
// You may redistribute this software provided the original
// archive is UNCHANGED and a link back to my web page,
// http://harmlesslion.com, is provided as the author's site.
// It is acceptable to link directly to a subpage at harmlesslion.com
// provided that page offers a URL for that purpose
//
// Source code, if available, is provided for educational purposes
// only. You are welcome to read it, learn from it, mock
// it, and hack it up - for your own use only.
//
// Please contact me before distributing derived works or
// ports so that we may work out terms. I don't mind people
// using my code but it's been outright stolen before. In all
// cases the code must maintain credit to the original author(s).
//
// -COMMERCIAL USE- Contact me first. I didn't make
// any money off it - why should you? ;) If you just learned
// something from this, then go ahead. If you just pinched
// a routine or two, let me know, I'll probably just ask
// for credit. If you want to derive a commercial tool
// or use large portions, we need to talk. ;)
//
// Commercial use means ANY distribution for payment, whether or
// not for profit.
//
// If this, itself, is a derived work from someone else's code,
// then their original copyrights and licenses are left intact
// and in full force.
//
// http://harmlesslion.com - visit the web page for contact info
//
